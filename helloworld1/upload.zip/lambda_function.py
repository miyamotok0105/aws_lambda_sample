
def lambda_handler(event, context):
    res = "!!"
    return res

